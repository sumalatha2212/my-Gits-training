#!/bin/sh 
for ((i=1;i<=5;i=i+1)); do
	echo "Iteration:$i"
else "this is five"
done 


